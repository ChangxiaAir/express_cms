<template>
<div class="about">
    <h2>JWT demo</h2>

    <br />
    <button @click="getArticleCate">获取文章分类信息</button>

    <br>

    <ul>
        <li v-for="item of list">{{item.title}}</li>
    </ul>
</div>
</template>

<script>
export default {
    name: "home",
    data() {
        return {
            msg: "this is about",
            list:[]
        };
    },
    methods: {
        getArticleCate() {
           var _that=this;
            this.$http
                .get("http://localhost:3000/api/v1/articleCate")
                .then(function (response) {
                    console.log(response);
                    _that.list=response.data.result;
                })
                .catch(function (error) {
                    console.log(error);
                });
        },
    }
};
</script>
