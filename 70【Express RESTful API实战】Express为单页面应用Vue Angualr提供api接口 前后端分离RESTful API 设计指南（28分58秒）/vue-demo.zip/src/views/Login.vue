<template>
<div class="login">
    <h2>登录</h2>

    <button @click="doLogin">执行登录</button>
</div>
</template>

<script>
export default {
    name: "home",
    data() {
        return {
            msg: "this is about"
        };
    },
    methods: {
        doLogin() {
            this.$http
                .post("http://localhost:3000/api/v1/doLogin",{
                    username:"张三",
                    pwd:"123456"
                })
                .then(function (response) {
                    console.log(response);
                })
                .catch(function (error) {
                    console.log(error);
                });

        }
    }
};
</script>
