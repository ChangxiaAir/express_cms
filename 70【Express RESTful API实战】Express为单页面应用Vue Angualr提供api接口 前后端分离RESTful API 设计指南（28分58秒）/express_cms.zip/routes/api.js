const express = require("express");

var router = express.Router()
const v1 = require("./api/v1")
const v2 = require("./api/v2")
const v3 = require("./api/v3")
//挂载路由
router.use("/v1", v1)
router.use("/v2", v2)
router.use("/v3", v3)
module.exports = router