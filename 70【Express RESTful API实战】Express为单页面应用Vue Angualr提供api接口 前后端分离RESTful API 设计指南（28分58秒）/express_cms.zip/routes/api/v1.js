const express = require("express");
var router = express.Router();
const ArticleCateModel = require("../../model/articleCateModel");

router.get("/",(req,res)=>{
   res.send("api接口v1")
})

router.get("/focus",(req,res)=>{
     //只支持ajax请求
    // res.send({
    //     "success":true,
    //     "message":"获取数据成功"
    // })

    // res.json({
    //     "success":true,
    //     "message":"获取数据成功"
    // })

    //支持jsonp 以及ajax请求
    res.jsonp({
        "success":true,
        "message":"获取数据成功"
    })
 })
 
 router.get("/articleCate",async (req,res)=>{
    var resultList=await ArticleCateModel.find({});
    res.json({
        "success":true,
        "message":"获取数据成功",
        "result":resultList
    })
 })

 router.post("/doLogin",async (req,res)=>{
    var body=req.body;
    console.log(body)
    res.json({
        "success":true,
        "message":"登录成功",
        "result":body
    })

 })

 router.put("/editUser",async (req,res)=>{
    var body=req.body;
    console.log(body)
    res.json({
        "success":true,
        "message":"修改用户成功",
        "result":body
    })

 })

 
 router.delete("/deleteUser",async (req,res)=>{
     var id=req.query.id;
    var body=req.body;
    console.log(body)
    res.json({
        "success":true,
        "message":"删除数据成功",
        "result":body,
        "id":id
    })

 })

 module.exports = router