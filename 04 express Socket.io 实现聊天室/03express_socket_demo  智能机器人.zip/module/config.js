/**
 * Created by Administrator on 2017/10/23 0023.
 */
var dbUrl = 'mongodb://localhost:27017/koa';


module.exports={

    dbUrl:dbUrl
}