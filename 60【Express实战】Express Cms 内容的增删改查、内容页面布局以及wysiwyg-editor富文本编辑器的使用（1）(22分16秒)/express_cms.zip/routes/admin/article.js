const express = require("express");
var router = express.Router();

router.get("/", async (req, res) => {

    res.render("admin/article/index.html")
})
router.get("/add", (req, res) => {
    res.render("admin/article/add.html")
})


module.exports = router