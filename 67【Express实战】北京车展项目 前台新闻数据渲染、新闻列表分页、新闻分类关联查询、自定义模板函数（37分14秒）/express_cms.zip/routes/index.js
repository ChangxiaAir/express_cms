const express = require("express");
const FocusModel = require("../model/focusModel");
const NavModel = require("../model/navModel");
const ArticleModel = require("../model/articleModel");
const ArticleCateModel = require("../model/articleCateModel");


const url= require("url");
const mongoose = require("../model/core");
const {formatTime} = require("../model/tools");
var router = express.Router()


router.use(async (req, res, next) => {      
   var pathname=url.parse(req.url).pathname;
   //获取公共的数据
   var navResult= await NavModel.find({"position":2}).sort({"sort":-1});
   req.app.locals.navList=navResult;
   // console.log(navResult);
   req.app.locals.pathname=pathname;
   //全局模板函数
   req.app.locals.formatTime=formatTime;
   
   console.log(pathname);

   next()
})


router.get("/",async (req,res)=>{

   var focusResult=await FocusModel.find({"type":1}).sort({"sort":-1})
   res.render("default/index.html",{
      focusList:focusResult
   })
})

router.get("/overview.html",(req,res)=>{
   res.render("default/overview.html")
})

router.get("/news.html",async (req,res)=>{
   //获取新闻数据
   var page = req.query.page || 1;
   var cid = req.query.cid || "";
   var pageSize = 3;
   var json = {};  //条件

   // var result =await ArticleModel.find({}).skip((page-1)*pageSize).limit(pageSize);

   //获取新闻中心的子分类   5f561dae10fc462a0c265ec0
   if(cid){
      json=Object.assign(json,{
         "cid":mongoose.Types.ObjectId(cid)
      })
   }else{
      var cateResult =await ArticleCateModel.find({"pid":mongoose.Types.ObjectId("5f561dae10fc462a0c265ec0")});
      var tempArr=[];
      cateResult.forEach((value)=>{
         tempArr.push(value._id);
      })
      json=Object.assign(json,{
         "cid":{ $in:tempArr}
      })
   }

   var result = await ArticleModel.aggregate([
       {
           $lookup: {
               from: "article_cate",
               localField: "cid",
               foreignField: "_id",
               as: "cate"
           }
       },
       {
           $match: json
       },
       {
           $sort: { "add_time": -1 }
       }, 
       {
           $skip: (page - 1) * pageSize
       }, 
       {
           $limit: pageSize
       }

   ])

   var count = await ArticleModel.count(json)

   res.render("default/news.html", {
       newsList: result,
       totalPages: Math.ceil(count / pageSize),
       page: page,
       cid:cid
   })

})

router.get("/services.html",(req,res)=>{
   res.render("default/services.html")
})
router.get("/contact.html",(req,res)=>{
   res.render("default/contact.html")
})
router.get("/content_:id.html",async (req,res)=>{

   var id=req.params.id;
   var result = await ArticleModel.find({"_id":id})
   res.render("default/news_content.html",{
      list:result[0]
   })
})



 
module.exports = router